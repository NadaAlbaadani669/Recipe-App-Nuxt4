import { defineStore } from 'pinia'
import {type Recipe} from '@/types/types';

export const useRecipeStore = defineStore('recipe', ()=>{
  // const favRecipes = 
})
